package com.fptu.evstation.rental.evrentalsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EvRentalSystemApplicationTests {

    @Test
    void contextLoads() {
    }

}
