package com.fptu.evstation.rental.evrentalsystem.entity;

public enum AccountStatus {
    ACTIVE, INACTIVE, BANNED
}
