package com.fptu.evstation.rental.evrentalsystem.entity;

public enum VerificationStatus {
    PENDING, APPROVED, REJECTED
}
